// PICK finds the k-th smallest number in A[0...n-1].
// Worst-case time complexity: n.
// Worst-case memory complexity: log n.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef int bool;
#define true  1
#define false 0

typedef int Basetype;
// Basetype must be a primitive ordered type:
// int, unsigned int, long; float, double.
// Avoid real numbers: precision may cause problems.

// Forward declarations of help functions:
void swap(Basetype * x, Basetype * y);
void sort(Basetype M[], int start, int final); // Sorts M[start...final-1].
int Partition(Basetype arr[], int len, int splitter, bool smallerFirst);

// Algorithm itself:

#define ROWS 21
// ROWS must be an odd number greater than 5.

#define MIDDLE 11
// MIDDLE must be ROWS/2 (rounded upwards).

#define N0 200
// Choose a reasonable value for N0.
// N0 must be greater than ROWS.

Basetype PICK(Basetype A[], int n, int k) {
   int s, f, i, j, L1, L2;
   Basetype M;

   start:

   // Bottom:
   if (n < N0) {
     sort(A, 0, n);
     return A[k-1];
   }

   // Split the array into a table ROWS x (n / ROWS)
   // and find the median of each column:
   s = 0;
   f = ROWS;
   while (f <= n) {
     sort(A, s, f);
     s = f;
     f += ROWS;
   }
   if (s < n) sort(A, s, n);

   // Move the medians of the columns
   // to the beginning of the array:
   i = 0;
   j = MIDDLE;
   s = 0;
   f = ROWS;
   while (f <= n) {
     swap(&A[i], &A[j]);
     s = f;
     f += ROWS;
     j += ROWS;
     ++i;
   }
   if (s < n) {
     j = (s + n - 1) >> 1;
     swap(&A[i], &A[j]);
   }

   // Find the median of the medians:
   M = PICK(A, i, i>>1);

   // Calculate the rank of M among the elements of A:
   L1 = 0;
   L2 = 0;
   for (i = 0; i < n; ++i) {
     if (A[i] < M)  ++L1;
     if (A[i] <= M) ++L2;
   }

   // Check if M is the answer:
   if ((L1 <= k) && (k <= L2)) return M;

   // Erase 1/4 of the elements:
   if (k < L1) {
     // Put the small numbers at the beginning:
     n = Partition(A, n, M, true);
   }
   else { // k > L2
     // Put the big numbers at the beginning:
     n = Partition(A, n, M, false);
     k -= L2;
   }
   goto start; // The tail recursion has been replaced with a loop.
}

// Help functions:

void swap(Basetype * x, Basetype * y) {
  Basetype z = *x;
  *x = *y;
  *y = z;
}

void sort(Basetype M[], int start, int final) {
  //
  // Sorts M[start...final-1].
  //
  // Because final - start <= N0 = const
  // when 'sort' is called by PICK,
  // the time complexity of this routine
  // affects only the constant factor
  // of the time complexity of PICK,
  // but not the order of its time complexity.
  // For a better constant factor,
  // use a faster sorting algorithm.
  //
  int i, j;
  for (i = start+1; i < final; ++i) {
    j = i;
    while ((j > start) && (M[j] < M[j-1])) {
      swap(&M[j], &M[j-1]);
      --j;
    }
  }
}

int Partition1(Basetype arr[], int len, int splitter) {
  // This algorithm is similar to Hoare's partition
  // but does not put the splitter between the two groups.
  int i = -1;
  int j = len;
  again:
  do {
    ++i;
  }
  while (arr[i] < splitter); // splitter must be in arr!
  do {
    --j;
    if (j <= i) return i;
  }
  while (arr[j] >= splitter);
  swap(&arr[i], &arr[j]);
  goto again;
}

int Partition2(Basetype arr[], int len, int splitter) {
  // This algorithm is similar to Partition1
  // but puts the big elements at the beginning.
  int i = -1;
  int j = len;
  again:
  do {
    ++i;
  }
  while (arr[i] > splitter); // splitter must be in arr!
  do {
    --j;
    if (j <= i) return i;
  }
  while (arr[j] <= splitter);
  swap(&arr[i], &arr[j]);
  goto again;
}

int Partition(Basetype arr[], int len, int splitter, bool smallerFirst) {
  if (smallerFirst)
    return Partition1(arr, len, splitter);
  else
    return Partition2(arr, len, splitter);
}

// Test functions:

bool testCorrectnessByInput(Basetype A[], int n, int k) {
  Basetype ans1, ans2;
  Basetype* B;
  int i;
  B = (Basetype*) malloc(n * sizeof(Basetype));
  for (i = 0; i < n; ++i)
    B[i] = A[i];
  sort(B, 0, n);
  ans1 = B[k-1];
  free(B);
  ans2 = PICK(A, n, k);
  return (ans1 == ans2);
}

void generateRandomInput(Basetype A[], int n, int * k) {
  int i;
  for (i = 0; i < n; ++i) {
    A[i] = random(10000);
  }
  *k = random(n) + 1;
}

bool testCorrectnessSingleRandom(Basetype A[], int n) {
  int k;
  generateRandomInput(A, n, &k);
  return testCorrectnessByInput(A, n, k);
}

bool testCorrectnessMultipleRandom(Basetype A[], int len, int numTests) {
  for (; numTests > 0; --numTests) {
    if (!testCorrectnessSingleRandom(A, len))
      return false;
  }
  return true;
}

bool testCorrectness() {
  int arrLen = 5000;
  int testsCount = 1000;
  Basetype* arr = (Basetype*) malloc(arrLen * sizeof(Basetype));
  bool result = testCorrectnessMultipleRandom(arr, arrLen, testsCount);
  free(arr);
  return result;
}

time_t testSpeedBySingleLength(int arrLen) {
  int testsCount, k;
  time_t t1, t2, deltaT;
  Basetype* arr = (Basetype*) malloc(arrLen * sizeof(Basetype));
  t1 = time(NULL);
  for (testsCount = 10000; testsCount > 0; --testsCount) {
    generateRandomInput(arr, arrLen, &k);
    PICK(arr, arrLen, k);
  }
  t2 = time(NULL);
  free(arr);
  return (t2 - t1);
}

int main() {
  int k, Len;
  time_t totalTime;
  randomize();
  printf("\n\n");
  printf((testCorrectness) ? "Correct.\n\n" : "Incorrect.\n\n");
  printf("Speed test:\n");
  for (k = 1; k <= 9; ++k) {
    Len = k * 1000;
    totalTime = testSpeedBySingleLength(Len);
    printf("Length: %d.   Total time: %d.\n", Len, totalTime);
  }
  printf("\n");
  return 0;
}